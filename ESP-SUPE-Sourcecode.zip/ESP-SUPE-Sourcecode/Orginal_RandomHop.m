%%
clc;
clear;
close all;
% rng(1);
load('pqfile.mat','numberOfUsers','numberOfServer','SizeTask','InF','OutF','MemTask','Deadline','Generate','upDead','MemServer','CpuBst','A','B','P','x','y','c','index1','Arand','Brand','','','','','')

numberOfBTS=20;  
% _____________________________matrix % User Propertice____________________

input=randi([1 10]);
penalty=zeros(numberOfUsers,numberOfBTS);
totalPenalty=0;
PDST=0;
PDSTofTASK=zeros(numberOfUsers,1);

% _________________________________________________________________________

% _________________________________________________________________________
DisUserBst=zeros(numberOfUsers,numberOfBTS);

% _________________________________________________________________________
ExeTime=zeros(numberOfUsers,numberOfBTS);
T_avail=zeros(numberOfUsers);
waitingTime=zeros(numberOfUsers);
ReadyTime=zeros(numberOfUsers);
AvailTime=zeros(1,numberOfBTS);
ResponseTime=zeros(numberOfUsers,numberOfBTS);
TTime=zeros(numberOfUsers,numberOfBTS);
% _________________________________________________________________________
Xij=zeros(numberOfUsers,numberOfBTS);
hh=zeros(numberOfUsers,numberOfBTS);
XijBefore=zeros(numberOfUsers,numberOfBTS);
user=zeros(numberOfUsers);
% _________________________________________________________________________
SelectServer=zeros(1,numberOfServer);
% _________________________________________________________________________


% minAllowableDistance = 5;
% minAllow=0.01;


Bandwith = A.*B ;
Prop=A.*P;
% ---------------------------Relation Edges between BTSes------------------
xn = [1 1 2 2 2 2 3 3 3 3 3 3 4 4 4 4 5 5 5 6 6 7 7 7 8 8 9 9 10 10 10 11 11 11 12 13 14 14 15 16 18 19 ];
yn = [2 14 3 6 13 5 5 4 12 16 7 6 7 8 11 19 6 9 10 7 9 8 10 17 12 9 16 13 15 13 11 12 15 18 16 17 15 18 19 20 19 20 ];
G = graph(xn,yn);
% ----------------------------------number Of Users------------------------

% ----------------------------------------------------------
XData = [2 2 2 2 4 4 4 4 6 6 6 6 8 8 8 8 10 10 10 10 ];
YData = [2 4 6 8 2 4 6 8 2 4 6 8 2 4 6 8 2 4 6 8 ];




    
%               fg=sum(CpuBst)
                sumCpu=sum(CpuBst);
                AvgCpuServer=sumCpu/numberOfServer;
    
 

%    [sortdead,dead]=sort(upDead);
%    [sortstart,start]=sort(Generate);
%    ff=find(start(1,1)==dead);
%    dead(ff)=[];
    keeperX = x(1);
    keeperY = y(1);
    counter = 1;
 ListServer=zeros(numberOfUsers,numberOfServer);
        for k = 1 : numberOfUsers   
            thisX = x(k);
            thisY = y(k);
            distances = sqrt((thisX-keeperX).^2 + (thisY - keeperY).^2);
            minDistance = min(distances);
            % if minDistance >= minAllowableDistance
            keeperX(counter) = thisX;
            keeperY(counter) = thisY;
            counter = counter + 1;
            
              for b=1:numberOfBTS
                DisUserBst(k,b) = sqrt((thisX-XData(b)).^2 + (thisY - YData(b)).^2);
              end

                  % user assign to BST
                 [minDis,b]=min(DisUserBst(k,:));
                 % user check with all server BST
                   if (sum((b-index1)==0))
                    ListServer(k,b)=k;
                    user(k)=k;
                   
%__________________________________________________________________________
                   
                   else
                          all=zeros(1,numberOfServer);
                          MinHop=zeros(1,numberOfServer);
                        for s=1:numberOfServer
                            store=0;
                          
                            [path,Hop]=shortestpath(G,b,index1(s));
                             AllPath=path(1,:);
                     MinHop(s)=Hop;
                    SelectServer(s)=AllPath(end);

                        end
                    idxMin = find(MinHop==min(MinHop)); 
                   all= SelectServer(idxMin);
                    if length(all)==1
                       select=all;
                    else                        
                         
                          select= randsample(all,1);
%                          
                    end
                    
                SelectServer=select;
                 ListServer(k,select)=k;
                
                   end
                ix = sum(abs(ListServer))~=0;
                N = ListServer(:, ix);
                servers=find(ix);
        end
          for i=1:length(servers)
            task=nonzeros(N(:,i));
            disp(["Server " +i," : "])
            disp(task)
            H=intersect(user,task); 
            [sortstart,start]=sort(Generate(task));
            for j=1:length(task)
                 if j==1
               
            v = find(Generate(task)==min(Generate(task)));
            if length(v)>1
               l=task(v);
               ll=upDead(l);
               nn = min(ll);
               kl=find(nn == upDead(task));
               k=task(kl);
               disp(["Task "+k," is running"])
            else
            kn=find(sortstart(1)==Generate(task));
            
                k=task(kn);
                disp(["Task "+k," is running"])
                dd=find(k==task);
                task(dd)=[];
                [sortdead,dead]=sort(upDead(task));
                d=find(upDead(k)==sortdead);

            end
         
                 else
                     round=ceil(AvailTime(1,servers(i)));
                    bn=find(Generate(task)<=round);
                    if length(bn)==1
                        k=task(bn);
                        disp(["Task "+k," is running"])
                        dd=find(k==task);
                        task(dd)=[];
                    else if length(bn)>1
                        km =find(Generate(task)==min(Generate(task)));
                         if length(km)>1
                           l=task(km);
                           ll=upDead(l);
                           nn = min(ll);
                           kl=find(nn == upDead(task));
                           k=task(kl);
                           disp(["Task "+k," is running"])
                        else
                            k=task(km);
                            disp(["Task "+k," is running"])
                            dd=find(k==task);
                            task(dd)=[];
                         end
                        end
                    end
                 end
                kk=intersect(H,k); 
                if length(kk)==1
                       ReadyTime(kk)=Generate(kk);
                       disp(["ReadyTime user "+kk,ReadyTime(kk)]);
                       T_avail(kk)=Generate(kk);
                       if T_avail(kk)>=AvailTime(1,servers(i))
                           waitingTime(kk)=0;
                       else
                           waitingTime(kk)=AvailTime(1,servers(i))-T_avail(kk);
                       end
                       ExeTime(kk,servers(i))=(SizeTask(kk,1)/CpuBst(servers(i)))*1000;
                       ResponseTime(kk,servers(i))= ExeTime(kk,servers(i))+ waitingTime(kk);
                       AvailTime(1,servers(i))=  AvailTime(1,servers(i))+ExeTime(kk,servers(i));
                         Xij(kk,servers(i))=1;
                        TotalCunter=sum(Xij,1);
                       if ResponseTime(kk,servers(i))> upDead(kk,1)
                           penalty(kk,servers(i))=ResponseTime(kk,servers(i))-upDead(kk,1);
                           totalPenalty=sum(penalty,2);
                           totalPenalty=sum(totalPenalty);
                       else
                            PDSTofTASK(kk)=1;
                            PDST=PDST+1;
                       end
                      
                else
                     
                           [minDis,b]=min(DisUserBst(k,:));
                            store=0;
                            Band=zeros(numberOfBTS,numberOfBTS);
                            Delay=zeros(numberOfBTS,numberOfBTS);
                            Trasn=zeros(numberOfBTS,numberOfBTS);
                            [path,Hop]=shortestpath(G,b,servers(i));
                            AllPath=path(1,:);
                     
                 if length(AllPath)>2
                         
                        for p=1:length(AllPath)
                          
                            currentPath= AllPath(p); 
                            CEnd=p+1;
                            if CEnd>length(AllPath)
                                break;
                            end
                            NextPath=AllPath(p+1);
                            Band(currentPath,NextPath)=  Bandwith(currentPath,NextPath);  
                            Delay(currentPath,NextPath)= Prop(currentPath,NextPath);  
                            Trasn(currentPath,NextPath)=((InF(k)+OutF(k))/Band(currentPath,NextPath))*8;
                            TTime(k,servers(i))= TTime(k,servers(i))+Trasn(currentPath,NextPath);
                            ReadyTime(k)=Generate(k)+ TTime(k,servers(i));
                        end
                           ReadyTime(k)=Generate(k)+  TTime(k,servers(i));
                           disp(["ReadyTime user "+k,ReadyTime(k)]);
                            BandW=sum(Band,2);
                            BandW=sum(BandW);
                            DelayProp=sum(Delay,2);
                            DelayProp=sum(DelayProp);
%                           if Bandwith(AllPath(1),AllPath(end))==0
%                           Bandwith(AllPath(1),AllPath(end))=BandW;
                            Prop(AllPath(1),AllPath(end))=DelayProp*2;
                            T_avail(k)=Prop(b,servers(i))+TTime(k,servers(i))+Generate(k);
                            if T_avail(k)>=AvailTime(1,servers(i))
                              waitingTime(k)=0;
                            else
                              waitingTime(k)=AvailTime(1,servers(i))-T_avail(k);
                            end
                            ExeTime(k,servers(i))=(SizeTask(k,1)/CpuBst(servers(i)))*1000; 
                            AvailTime(1,servers(i))= (AvailTime(1,servers(i))+ExeTime(k,servers(i)));
                            ResponseTime(k,servers(i))=TTime(k,servers(i))+(Prop(b,servers(i)))+ExeTime(k,servers(i))+ waitingTime(k);
%                           end
                    Xij(k,servers(i))=1;
                    TotalCunter=sum(Xij,1);
                 else
                       TTime(k,servers(i))=((InF(k)+OutF(k))/Bandwith(b,servers(i)))*8;
                       ReadyTime(k)=Generate(k)+  TTime(k,servers(i));
                       disp(["ReadyTime user "+k,ReadyTime(k)]);
                       T_avail(k)=Prop(b,servers(i))+TTime(k,servers(i))+Generate(k);
                        if T_avail(k)>=AvailTime(1,servers(i))
                            waitingTime(k)=0;
                        else
                            waitingTime(k)=AvailTime(1,servers(i))-T_avail(k);
                        end
                       ExeTime(k,servers(i))=(SizeTask(k,1)/CpuBst(servers(i)))*1000;   
                       AvailTime(1,servers(i))= AvailTime(1,servers(i))+ ExeTime(k,servers(i));
                       ResponseTime(k,servers(i))=TTime(k,servers(i))+Prop(b,servers(i))+ExeTime(k,servers(i))+ waitingTime(k);
                 end
             
                    
                    
                    Xij(k,servers(i))=1;
                    TotalCunter=sum(Xij,1);

                  
                    if ResponseTime(k,servers(i))> upDead(k,1)
                       penalty(k,servers(i))=ResponseTime(k,servers(i))-upDead(k,1);
                       totalPenalty=sum(penalty,2);
                       totalPenalty=sum(totalPenalty);
                         else
                        PDSTofTASK(k)=1;
                          PDST=PDST+1;
                    end             
                end
            end
          end
                       Res=sum(ResponseTime,2);
                       SumResponse=sum(Res);
                       AverageResponseTime=SumResponse/numberOfUsers;
                       RatePDST=(PDST/numberOfUsers)*100;
            
      
         
% -------------------------------------------------------------------------

% r=1.15;
% t=0:0.1:6.3;
% for i=1:8
% a=[1,1,1,1,3,3,3,3,5,5,5,5,7,7,7,7,9,9,9,9];
% b=[1,3,5,7,1,3,5,7,1,3,5,7,1,3,5,7,1,3,5,7 ];
% p =r.*sin(t)+a(i);
% o=r.*cos(t)+b(i);
% plot(p,o, 'k');hold on
% end
% ---------------------------------Output Plot-----------------------------
plot(keeperX, keeperY, 'm*');
hold on;
h= plot(G,'b -o', 'MarkerSize', 20,'LineWidth', 2);
plot(Arand,Brand,'r o', 'MarkerSize', 20,'markerfacecolor','r');
h.XData = [2 2 2 2 4 4 4 4 6 6 6 6 8 8 8 8 10 10 10 10 ];
h.YData = [2 4 6 8 2 4 6 8 2 4 6 8 2 4 6 8 2 4 6 8 ];
axis([0,12,0,10])
grid on;
% _______________________________________________________________________________________