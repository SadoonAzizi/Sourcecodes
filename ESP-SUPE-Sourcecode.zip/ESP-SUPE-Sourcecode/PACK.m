%%
clc;
clear;
close all;
% rng('1')
load('CreatModel_Data.mat')

% NumberOfServer = input('Enter number Of Server: '); 
N = input('Enter number Of Iteration In K-means++: '); 
WorkloadServer=zeros(1,NumberOfServer);
DisUserBst=zeros(BTS,NumberOfServer);
yij=zeros(BTS,NumberOfServer);

BestCost=inf;

empty_individual.Server = [];
empty_individual.MyCost = [];
empty_individual.WorkloadServer = [];

Solution= repmat(empty_individual, N, 1);

%      for w=1:BTS
%         workload(1,w) =randi([2000 5000]);     
%      end 
workload=model.SumWorkloadAllBTS; 

for lg=1:N
   [idx,X,C]= cluster(NumberOfServer); 
   for c=1:NumberOfServer
      [a,ia,ib] = intersect(X,C(c,:),'rows');
      S(1,c)=ia;
      S(1,c)=P(ia);
   end
   WorkloadServer=zeros(1,NumberOfServer);
   MyCost=0;
   for b=1:BTS
    for s=1:NumberOfServer
      DisUserBst(b,s) = (X(b,1)-C(s,1)).^2 + (X(b,2) -C(s,2)).^2;
    end
    [minDis,s]=min(DisUserBst(b,:));
    yij(b,s)=1;
    WorkloadServer(1,s)=WorkloadServer(1,s)+workload(b,1);
    MyCost=MyCost+workload(b,1)*DisUserBst(b,s)*yij(b,s);
   end

Solution(lg).WorkloadServer=WorkloadServer;
Solution(lg).MyCost=MyCost;
Solution(lg).Server=S;
   if MyCost<BestCost
       BestCost=MyCost;
       BestSol=Solution(lg);
       Cj=C;
       Cluster=idx;
       Yij=yij;
%        PlotSolution_PACK();
%        hold on
%        plot(C(:,1),C(:,2),'Y o', 'MarkerSize', 30,'markerfacecolor','Y');
%        for s=1:NumberOfServer
%          text(C(s,1)-0.2,C(s,2),['S' num2str(s)],'Color',[0 0 0],'FontSize',14)
%        end
   end
end
[STDworkload,sumWork,WorklodOfBTS,WorkloadOfServer,WorkLoadMIPS,modell]=Evaluation(BestSol.Server,NumberOfServer,Users,BTS,model,numBTS);
Yij=modell.Xij;
ListBTSs=modell.ListBTS;
user=modell.user;
sumYij=sum(Yij,1);
    disp("Sum_Workload "+sumWork);
    disp("SD_Result "+STDworkload);
%     figure(1);
%     PlotSolution_GA(BestSol.Server,model,NumberOfServer);
    Enter = input('How many Algorithms do you Run?  '); 
    Enter=Enter*2;
   for i=1:Enter
    disp("Please select one of the algorithms");
    disp("1- Random ");
    disp("2- RandomHop ");
    disp("3- Greedy");
    disp("4- RouletteWheel ");
    disp("5- Balance ");
    Algorithm = input('Enter number: '); 
    Schedul = input('1: FIFO    OR   2:Deadline aware : '); 
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=LoadDistribution(BestSol.Server,WorklodOfBTS,WorkloadOfServer,BTS,Algorithm,ListBTSs,Schedul);
    disp("AVG Respons "+AverageResponseTime); 
   end
   
