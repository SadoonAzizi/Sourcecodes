function PlotSolution_PACK()
xn = [1 1 2 2 3 3 4 5 5 6 6   7  8 9 ];
yn = [2 4 3 5 4 6 7 6 8 7 10  10 9 10];
G = graph(xn,yn);
XData = [5 3 6 7 3.5 5 7 5 7   9 ];
YData = [8 6 6 7 3.5 4 5 2 2.5 3 ];
figure(1)
h= plot(G,'b -o', 'MarkerSize', 30,'LineWidth', 2);

h.XData = [5 3 6 7 3.5 5 7 5 7   9 ];
h.YData = [8 6 6 7 3.5 4 5 2 2.5 3 ];
text(5,8,'1','Color',[1 1 1],'FontSize',14)
text(3,6,'2','Color',[1 1 1],'FontSize',14)
text(6,6,'3','Color',[1 1 1],'FontSize',14)
text(7,7,'4','Color',[1 1 1],'FontSize',14)
text(3.5,3.5,'5','Color',[1 1 1],'FontSize',14)
text(5,4,'6','Color',[1 1 1],'FontSize',14)
text(7,5,'7','Color',[1 1 1],'FontSize',14)
text(5,2,'8','Color',[1 1 1],'FontSize',14)
text(7,2.5,'9','Color',[1 1 1],'FontSize',14)
text(9,3,'10','Color',[1 1 1],'FontSize',14)
axis([0,12,0,10])
grid on;
end