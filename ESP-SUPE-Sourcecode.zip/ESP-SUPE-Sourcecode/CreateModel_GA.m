function model=CreateModel(User,BTS,NumberOfServer)
%  rng(1);
SizeTask=zeros(User,1);
RateTask=zeros(User,1);
DisUserBst=zeros(User,BTS);
Res=zeros(1,BTS);
selectS=zeros(User,BTS);
MemServer=zeros(1,BTS);
CpuBst=zeros(1,NumberOfServer);
CpuServer=zeros(1,NumberOfServer);

InF=zeros(User,1);
OutF=zeros(User,1);
MemTask=zeros(User,1);

Generate=zeros(User,1);
ProbUser=zeros(User,1);
% _________________________________________________________________________
% _________________________________________________________________________
A=[ 0 1 0 1 0 0 0 0 0 0;
    1 0 1 0 1 0 0 0 0 0;
    0 1 0 1 0 1 0 0 0 0;
    1 0 1 0 0 0 1 0 0 0;
    0 1 0 0 0 1 0 1 0 0;
    0 0 1 0 1 0 1 0 0 1;
    0 0 0 1 0 1 0 0 0 1;
    0 0 0 0 1 0 0 0 1 0;
    0 0 0 0 0 0 0 1 0 1;
    0 0 0 0 0 1 1 0 1 0;];

B = 1000;
P = 0.002 + (0.005-0.002) * rand(BTS,BTS);
Bandwith = A.*B ;
Prop=A.*P;

% ---------------------------Relation Edges between BTSes------------------
xn = [1 1 2 2 3 3 4 5 5 6 6   7  8 9 ];
yn = [2 4 3 5 4 6 7 6 8 7 10  10 9 10];
G = graph(xn,yn);
% ----------------------------------number Of Users------------------------
x = 10-8*rand(1,1000) ;
y = 10-9*rand(1,1000) ;

% ----------------------------------------------------------
XData = [5 3 6 7 3.5 5 7 5 7   9 ];
YData = [8 6 6 7 3.5 4 5 2 2.5 3 ];

c=randperm(10);
index1= randsample(c, 10); 
index1=sort(index1);
Arand = XData(index1);
Brand = YData(index1);
                randd=randi([1 10]);
        CpuServer =8000;     
     
    for i = 1 :User
            SizeTask(i,1) = randi([500 5000]); 
            RateTask(i,1)=randi([1 8]);
            InF(i,1) = randi([500 5000]);
            OutF(i,1) = randi([100 1000]);
            MemTask(i,1)= randi([32 64]);
            Generate(i,1)=randi([1 1000]);
    end
    keeperX = x(1);
    keeperY = y(1);
    counter = 1;
    for k=1:User
            thisX = x(k);
            thisY = y(k);
            distances = sqrt((thisX-keeperX).^2 + (thisY - keeperY).^2);
            minDistance = min(distances);
            % if minDistance >= minAllowableDistance
            keeperX(counter) = thisX;
            keeperY(counter) = thisY;
            counter = counter + 1;
            
              for b=1:BTS
                DisUserBst(k,b) = sqrt((thisX-XData(b)).^2 + (thisY - YData(b)).^2);
              end
    end
                 model.DisUserBst=DisUserBst;
                 model.randd=randd;
                 model.selectS=selectS;
                 model.Bandwith=Bandwith;
                 model.Prop=Prop;
                 model.G=G;
                 model.CpuServer=CpuServer;
                 model.RateTask=RateTask;
                 model.SizeTask=SizeTask;
                 model.InF=InF;
                 model.OutF=OutF;
                 model.MemTask=MemTask;
                 model.Generate=Generate;
                 model.ProbUser=ProbUser;
                 model.MemServer=MemServer;
                 model.CpuBst=CpuBst;
                 

        

    n=numel(index1);
    model.DisUserBst=DisUserBst;
    model.selectS=selectS;
    model.index1=index1;
    model.Arand=Arand;
    model.Brand=Brand;
    model.n=n;
    model.A=A;
    model.xn=xn;
    model.yn=yn;
    model.XData=XData;
    model.YData=YData;
    model.x=x;
    model.y=y;
    model.Bandwith=Bandwith;
    model.Prop=Prop;
    model.SizeTask=SizeTask;
    model.G=G;
    model.keeperX=keeperX;
    model.keeperY=keeperY;
save('CreatModel.mat')
end