
function [AverageComDelay,Workload,modell,result]=MyCost(Users,NumberOfServer,Server,BTS,model,top,numBTS)

rng('shuffle')
BTS=max(Server);
workloadAllBTS=zeros(numel(Users),BTS);
TTime=zeros(numel(Users),BTS);
ComDelay=zeros(numel(Users),BTS);
Xij=zeros(numel(Users),BTS);
user=zeros(1,numel(Users));
% _________________________________________________________________________
SelectServer=zeros(1,NumberOfServer);
workload=zeros(1,BTS);
workloadACO=zeros(1,BTS);
load=zeros(numel(Users),BTS);
loadACO=zeros(numel(Users),BTS);
%_________________________________________________________________________
RateTask=model.RateTask;
InF=model.InF;
OutF=model.OutF;
Bandwith=model.Bandwith;
SizeTask=model.SizeTasks;
CpuServer=model.CpuServer;

SizeTasks=model.SizeTasks;
InFs=model.InFs;
OutFs=model.OutFs;
Generates=model.Generates;
Probusers=model.Probusers;
UpDeads=model.UpDeads;
Deadlines=model.Deadlines;

if top==1
    Cpu_Bst=sort(CpuServer,'descend');
    for i = 1:NumberOfServer
        CpuBst(i)=Cpu_Bst(i);
    end
else
    CpuBst=CpuServer;
end
ListServer=zeros(numel(Users),NumberOfServer);
for k = 1 : numel(Users)
    % user assign to BST
    b=numBTS(k);
    workloadAllBTS(k,b)=(SizeTasks(k));
    workloadAllBTS_ACO(k,b)=(SizeTasks(k));
    SumWorkloadAllBTS_ACO=sum(workloadAllBTS_ACO,1);
    SumWorkloadAllBTS=sum(workloadAllBTS,1);
    % user check with all server BST
    if (sum((b-Server)==0))
        ListServer(k,b)=k;
        Xij(k,b)=1;
        user(1,k)=k;
        select=b;
    else
        all=zeros(1,NumberOfServer);
        MinHop=zeros(1,NumberOfServer);
        for s=1:NumberOfServer
            store=0;
            [path,Hop]=shortestpath(model.G,b,Server(s));
            AllPath=path(1,:);
            disp(k);
            MinHop(s)=Hop;
            SelectServer(s)=AllPath(end);
        end
        idxMin = find(MinHop==min(MinHop));
        all= SelectServer(idxMin);
        if length(all)==1
            select=all;
        else
            select= all;
        end
        SelectServer=select;
        ListServer(k,select)=k;
        Xij(k,SelectServer)=1;
    end
    ix = sum(abs(ListServer))~=0;
    N = ListServer(:, ix);
    servers=find(ix);
    if length(select)>1
        for i=1:numel(select)
            format("shortG");
            load(k,select(i))=(SizeTasks(k))/numel(select);
            loadACO(k,select(i))=(SizeTasks(k)/numel(select));
            workload(select(i))=(workload(select(i))+load(k,select(i)));
            workloadACO(select(i))=(workloadACO(select(i))+(SizeTasks(k)))/numel(select);
            b=numBTS(k);
            store=0;
            Band=zeros(BTS,BTS);
            Trasn=zeros(BTS,BTS);
            [path,Hop]=shortestpath(model.G,b,select(i));
            AllPath=path(1,:);
            
            if length(AllPath)>2
                for p=1:length(AllPath)
                    currentPath= AllPath(p);
                    CEnd=p+1;
                    if CEnd>length(AllPath)
                        break;
                    end
                    NextPath=AllPath(p+1);
                    Band(currentPath,NextPath)=  Bandwith(currentPath,NextPath);
                    Trasn(currentPath,NextPath)=((((InFs(k)+(OutFs(k)))/Band(currentPath,NextPath))))*8;
                    TTime(k,select(i))= TTime(k,select(i))+Trasn(currentPath,NextPath);
                    ComDelay(k,select(i))=TTime(k,select(i));
                end
                ComDelay(k,select(i))=(ComDelay(k,select(i))/numel(select));
                TTime(k,select(i))= (TTime(k,select(i))/numel(select));
            else
                TTime(k,select(i))=((((InFs(k)+sum(OutFs(k)))/Bandwith(b,select(i))))/numel(select))*8;
                ComDelay(k,select(i))=TTime(k,select(i));
            end
        end
    end
end
for i=1:length(servers)
    task=nonzeros(N(:,i));
    H=intersect(user,task);
    for k=1:numel(task)
        k=task(k);
        kk=intersect(H,k);
        if length(kk)==1
            if load(kk,servers(i))==0
                load(kk,servers(i))=(SizeTasks(kk));
                loadACO(kk,servers(i))=sum(SizeTasks(kk));
                workload(servers(i))=(workload(servers(i))+load(kk,servers(i)));
                workloadACO(servers(i))=workloadACO(servers(i))+(SizeTasks(kk));
            end
            TotalCunter=sum(Xij,1);
        else
            b=numBTS(k);
            store=0;
            Band=zeros(BTS,BTS);
            Trasn=zeros(BTS,BTS);
            [path,Hop]=shortestpath(model.G,b,servers(i));
            AllPath=path(1,:);
            if length(AllPath)>2
                for p=1:length(AllPath)
                    currentPath= AllPath(p);
                    CEnd=p+1;
                    if CEnd>length(AllPath)
                        break;
                    end
                    NextPath=AllPath(p+1);
                    Band(currentPath,NextPath)=  Bandwith(currentPath,NextPath);
                    Trasn(currentPath,NextPath)=(((InFs(k)+sum(OutFs(k)))/Band(currentPath,NextPath)))*8;
                    if TTime(k,servers(i))==0
                        TTime(k,servers(i))= TTime(k,servers(i))+Trasn(currentPath,NextPath);
                        ComDelay(k,servers(i))=TTime(k,servers(i));
                    end
                end
                BandW=sum(Band,2);
                BandW=sum(BandW);
                if load(k,servers(i))==0
                    load(k,servers(i))=(SizeTasks(k));
                    loadACO(k,servers(i))=(SizeTasks(k));
                    workload(servers(i))=(workload(servers(i))+load(k,servers(i)));
                    workloadACO(servers(i))=workloadACO(servers(i))+(SizeTasks(k));
                end
                TotalCunter=sum(Xij,1);
            else
                if TTime(k,servers(i))==0
                    TTime(k,servers(i))=(((InFs(k)+(OutFs(k)))/Bandwith(b,servers(i))))*8;
                    ComDelay(k,servers(i))= TTime(k,servers(i));
                end
                if load(k,servers(i))==0
                    load(k,servers(i))=(SizeTasks(k));
                    loadACO(k,servers(i))=(SizeTasks(k));
                    workload(servers(i))=(workload(servers(i))+load(k,servers(i)));
                    workloadACO(servers(i))=workloadACO(servers(i))+(SizeTasks(k));
                end
            end
            TotalCunter=sum(Xij,1);
        end
    end
end

%workload
ComDelay=ComDelay/60;
TTime=TTime/60;
workLoadServer=zeros(1,numel(Server));
for i=1:numel(Server)
    workLoadServer(1,Server(i))=(workload(Server(i))/CpuBst(i))/60;
    resultt(1,Server(i))=workload(Server(i))/60;
end
fff=find(resultt);
for i=1:numel(fff)
    result(i)=resultt(fff(i));
end
Workload=workLoadServer(Server);
Wsum=sum(workLoadServer);
format("shortG");
avg=sum(SumWorkloadAllBTS);
avgWorkload=(avg/sum(CpuServer))/60;
format("shortG");
STDload=std(Workload);

ResTTime=sum(ComDelay,1);
SumTtime=sum(ResTTime);
AverageComDelay=SumTtime/numel(RateTask);

modell.result=result;
modell.Xij=Xij;
modell.avgWorkload=avgWorkload;
modell.Wsum=Wsum;
modell.CpuBst=CpuBst;
modell.ListServer=ListServer;
modell.ComDelay=ComDelay;
modell.ResTTime=ResTTime;
modell.SumWorkloadAllBTS=SumWorkloadAllBTS;
modell.SumWorkloadAllBTS_ACO=SumWorkloadAllBTS_ACO;

end