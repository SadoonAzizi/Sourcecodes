function [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime] = FIFO(Server,BtsOnServer,userr)
load('CreatModel_Data.mat')
BTS=max(Server);
upDead=model.UpDeads;
ExeTime=zeros(numel(Users),BTS);
T_avail=zeros(numel(Users),8);
waitingTime=zeros(numel(Users),8);
ReadyTime=zeros(numel(Users),8);
AvailTime=zeros(1,BTS);
ResponseTime=zeros(numel(Users),BTS);
TTime=zeros(numel(Users),BTS);
penalty=zeros(numel(Users),BTS);
totalPenalty=0;
PDST=0;
PDSTofTASK=zeros(numel(Users),1);

for i=1:length(Server)
    [U,T]=find(BtsOnServer==Server(i));
    NumberTask=[U,T];
    gTime=zeros(numel(T),numel(T));
    task=zeros(numel(U),numel(T));
    H=zeros(numel(U),numel(T));
    for u=1:numel(U) 
        gTime(U(u),T(u))=MyData.Generates(U(u));
        task(u,u)=BtsOnServer(U(u),T(u));
        if (userr(U(u),T(u))==task(u,u))
            H(U(u),T(u))=1;
        else
            H(U(u),T(u))=0;
        end
    end
%     GeneratTime=nonzeros(gTime);
%     [sortstart,start]=sort(GeneratTime);
%     use=zeros(1,numel(sortstart));
%     tas=zeros(1,numel(sortstart));
%     for z=1:numel(sortstart)
%         [use(z),tas(z)]=find(gTime==sortstart(z),1,'first');
%     end
    for j=1:length(U)
        [r,c]=find(gTime==min(nonzeros(gTime)),1,'first');
        gTime(r,c)=0;
%         r=use(j);
%         c=tas(j);
%         if length(r)>1
        exe{i,j}=[r,c];
        
        if H(r,c)==1
            ReadyTime(r,c)=MyData.Generates(r);
            disp(["ReadyTime user "+r,ReadyTime(r,c)]);
            T_avail(r,c)=MyData.Generates(r);
            if T_avail(r,c)>=AvailTime(1,Server(i))
                waitingTime(r,c)=0;
            else
                waitingTime(r,c)=AvailTime(1,Server(i))-T_avail(r,c);
            end
            ExeTime(r,Server(i))=ExeTime(r,Server(i))+(MyData.SizeTasks(r)/CpuServer(i))*1000;
            ResponseTime(r,Server(i))= ExeTime(r,Server(i))+ waitingTime(r,c);
            AvailTime(1,Server(i))=  AvailTime(1,Server(i))+ExeTime(r,Server(i));
            Xij(r,Server(i))=1;
            TotalCunter=sum(Xij,1);
            if ResponseTime(r,Server(i))> upDead(r)
                penalty(r,Server(i))=ResponseTime(r,Server(i))-upDead(r);
                totalPenalty=sum(penalty,2);
                totalPenalty=sum(totalPenalty);
            else
                PDSTofTASK(r,c)=1;
                PDST=PDST+1;
            end
            
        else
            
             b=MyData.numBTS(r);
            store=0;
            Band=zeros(BTS,BTS);
            Trasn=zeros(BTS,BTS);
            [path,Hop]=shortestpath(G,b,Server(i));
            AllPath=path(1,:);
            
            if length(AllPath)>2
                
                for p=1:length(AllPath)
                    
                    currentPath= AllPath(p);
                    CEnd=p+1;
                    if CEnd>length(AllPath)
                        break;
                    end
                    NextPath=AllPath(p+1);
                    Band(currentPath,NextPath)=  Bandwith(currentPath,NextPath);
                    Trasn(currentPath,NextPath)=((InFs(r)+OutFs(r))/Band(currentPath,NextPath))*8;
                    TTime(r,Server(i))= TTime(r,Server(i))+Trasn(currentPath,NextPath);
                    ReadyTime(r,c)=MyData.Generates(r)+ TTime(r,Server(i));
                end
                ReadyTime(r,c)=MyData.Generates(r)+  TTime(r,Server(i));
                disp(["ReadyTime user "+r,ReadyTime(r,c)]);
                BandW=sum(Band,2);
                BandW=sum(BandW);
                T_avail(r,c)=TTime(r,Server(i))+MyData.Generates(r);
                if T_avail(r,c)>=AvailTime(1,Server(i))
                    waitingTime(r,c)=0;
                else
                    waitingTime(r,c)=AvailTime(1,Server(i))-T_avail(r,c);
                end
                ExeTime(r,Server(i))=(MyData.SizeTasks(r)/CpuServer(i))*1000;
                AvailTime(1,Server(i))= (AvailTime(1,Server(i))+ExeTime(r,Server(i)));
                ResponseTime(r,Server(i))=TTime(r,Server(i))+ExeTime(r,Server(i))+ waitingTime(r,c);
                %                           end
                Xij(r,Server(i))=1;
                TotalCunter=sum(Xij,1);
            else
                TTime(r,Server(i))=((InFs(r)+OutFs(r))/Bandwith(b,Server(i)))*8;
                ReadyTime(r,c)=MyData.Generates(r)+  TTime(r,Server(i));
                disp(["ReadyTime user "+r,ReadyTime(r,c)]);
                T_avail(r,c)=TTime(r,Server(i))+MyData.Generates(r);
                if T_avail(r,c)>=AvailTime(1,Server(i))
                    waitingTime(r,c)=0;
                else
                    waitingTime(r,c)=AvailTime(1,Server(i))-T_avail(r,c);
                end
                ExeTime(r,Server(i))=(MyData.SizeTasks(r)/CpuServer(i))*1000;
                AvailTime(1,Server(i))= AvailTime(1,Server(i))+ ExeTime(r,Server(i));
                ResponseTime(r,Server(i))=TTime(r,Server(i))+ExeTime(r,Server(i))+ waitingTime(r,c);
            end
            Xij(r,Server(i))=1;
            TotalCunter=sum(Xij,1);
            
            
            if ResponseTime(r,Server(i))> upDead(r)
                penalty(r,Server(i))=ResponseTime(r,Server(i))-upDead(r);
                totalPenalty=sum(penalty,2);
                totalPenalty=sum(totalPenalty);
            else
                PDSTofTASK(r,c)=1;
                PDST=PDST+1;
            end
        end
    end
    
    
end
Res=sum(ResponseTime,2);
SumResponse=sum(Res);
AverageResponseTime=SumResponse/sum(RateTask);
RatePDST=(PDST/sum(RateTask))*100;
OrderOfExecution=exe;
save('Scheduling.mat')
end

