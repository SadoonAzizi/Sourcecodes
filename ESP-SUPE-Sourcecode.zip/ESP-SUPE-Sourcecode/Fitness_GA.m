
function [STD,workLoadServer,avgWorkload]=Fitness_GA(Users,NumberOfServer,Server,BTS,model,numBTS)

rng('shuffle')
BTS=max(Server);
workloadAllBTS=zeros(numel(Users),BTS);

% _________________________________________________________________________

% _________________________________________________________________________
Xij=zeros(numel(Users),BTS);

user=zeros(1,numel(Users));
% _________________________________________________________________________
SelectServer=zeros(1,NumberOfServer);
workload=zeros(1,BTS);
load=zeros(numel(Users),BTS);
%_________________________________________________________________________

SizeTasks=model.SizeTasks;

    CpuBst=model.CpuServer;        

                format("shortG");
   
 ListServer=zeros(numel(Users),NumberOfServer);
        for k = 1 : numel(Users)   

           % user assign to BST
           b=numBTS(k);
           workloadAllBTS(k,b)=(SizeTasks(k));
           SumWorkloadAllBTS=sum(workloadAllBTS,1);
            % user check with all server BST
             if (sum((b-Server)==0))
                ListServer(k,b)=k;
                Xij(k,b)=1;
                user(1,k)=k;
              select=b;
                load(k,select)=(SizeTasks(k));
                workload(select)=workload(select)+(SizeTasks(k));
%__________________________________________________________________________
                   
             else

                          all=zeros(1,NumberOfServer);
                          MinHop=zeros(1,NumberOfServer);
                        for s=1:NumberOfServer
                           
                            store=0;
                            [path,Hop]=shortestpath(model.G,b,Server(s));
                             AllPath=path(1,:);
                     MinHop(s)=Hop;
                    SelectServer(s)=AllPath(end);

                        end
                    idxMin = find(MinHop==min(MinHop)); 
                   all= SelectServer(idxMin);
                    if length(all)==1
                       select=all;
                       load(k,all)=(SizeTasks(k));
                       workload(all)=workload(all)+(SizeTasks(k));
                    else  
%                          selc=sort(workload(all));
%                          selec=min(selc);
%                          sel=find(selc==selec);
%                          if numel(sel)>1
                          select= randsample(all,1);
                          load(k,select)=(SizeTasks(k));
                          workload(select)=workload(select)+(SizeTasks(k));
%                          else
%                           st=find(workload(all)==selec);
%                           select=all(st);
%                           load(k,select)=SizeTask(k);
%                           workload(select)=workload(select)+(SizeTasks(k));
%                          end
                    end
                 SelectServer=select;
                 ListServer(k,select)=k;
                 Xij(k,SelectServer)=1;
                   end
                  
                ix = sum(abs(ListServer))~=0;
                N = ListServer(:, ix);
                servers=find(ix);


        end

        
        

          for i=1:length(servers)
            task=nonzeros(N(:,i));
%             disp(["Server " +servers(i)," : "])
%             disp(task)       
          end
      
           
     
                        %workload
                        workLoads=zeros(1,numel(Server));
                        for i=1:numel(Server)
                         workLoads(1,Server(i))=(workload(Server(i)));
%                            ggg(1,Server(i))=(workload(Server(i))/numel(Server));   
                        end
                        tk=max(Server);
                        for i=1: numel(Server)   
                           workLoadServer(i)=workLoads(Server(i));
                        end
                      
                        format("shortG");
                        avg=sum(SumWorkloadAllBTS);
                        avgWorkload=(avg/numel(Server));
                        format("shortG");
                        STD=std(workLoadServer);

                       
                      modell.Xij=Xij;
                     
                      modell.avgWorkload=avgWorkload;
                      modell.CpuBst=CpuBst;
                      modell.ListServer=ListServer;
                      modell.SumWorkloadAllBTS=SumWorkloadAllBTS;

% save('pqfile.mat','AverageComDelay','Workload','Xij','ExeTime','ResponseTime','CpuBst','ListServer','ComDelay','ResTTime','SumWorkloadAllBTS','upDead')         
      

       
end