%%
clc;
clear;
close all;
%  rng(1);
 
%% Problem Definition
load('CreatModel_Data.mat')
nVar= model.index1;
Server= randsample(nVar,NumberOfServer); 
Server=P(Server);
            
[STDworkload,sumWork,WorklodOfBTS,WorkloadOfServer,WorkLoadMIPS,modell]=Evaluation(Server,NumberOfServer,Users,BTS,model,numBTS);
Yij=modell.Xij;
ListBTSs=modell.ListBTS;
user=modell.user;
sumYij=sum(Yij,1);
    disp("Sum_Workload "+sumWork);
    disp("SD_Result "+STDworkload);
%     figure(1);
%     PlotSolution_GA(Server,model,NumberOfServer);
    Enter = input('How many Algorithms do you Run?  '); 
    Enter=Enter*2;
   for i=1:Enter
    disp("Please select one of the algorithms");
    disp("1- Random ");
    disp("2- RandomHop ");
    disp("3- Greedy");
    disp("4- RouletteWheel ");
    disp("5- Balance ");
    Algorithm = input('Enter number: '); 
    Schedul = input('1: FIFO    OR   2:Deadline aware : '); 
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=LoadDistribution(Server,WorklodOfBTS,WorkloadOfServer,BTS,Algorithm,ListBTSs,Schedul);
    disp("AVG ResponseTime "+AverageResponseTime);
   end

