function [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=LoadDistribution(Server,WorklodOfBTS,WorkloadOfServer,BTS,Algorithm,ListBTSs,Schedul)
if Algorithm==1
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=Random(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul);
elseif  Algorithm==2
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=RandomHop(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul);
elseif  Algorithm==3
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=Greedy(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul);
elseif  Algorithm==4
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=RouletteWheel(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul);
elseif Algorithm==5
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=Balance(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul);
else
    disp("Out Of Range");
    
end
end
%-----------------------------------------------------------------RANDOM
function [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=Random(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul)

load('CreatModel_Data.mat')
rng('shuffle')
SizeTask=model.SizeTasks;
BTS=max(Server);
WorkloasS=zeros(1,max(Server));
BtsOnServer=zeros(numel(Users),max(Server));
USER=zeros(numel(Users),max(Server));
userr=zeros(sum(RateTask),sum(RateTask));
for B = 1 : BTS
    t=ListBTSs(:,B);
    USER=find(t);
    for U=1:numel(USER)
        if (sum((B-Server)==0))
            BtsOnServer(USER(U),MyData.task(USER(U)))=B;
            userr(USER(U),MyData.task(USER(U)))=B;
            WorkloasS(1,B)=WorkloasS(1,B)+(SizeTask(USER(U)));
            ListServer(B,B)=B;
            select=B;
        else
            select= randsample(Server,1);
            BtsOnServer(USER(U),MyData.task(USER(U)))=select;
            WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
            ListServer(B,select)=B;
        end
    end
end
if Schedul==1
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= FIFO(Server,BtsOnServer,userr);
else
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= DeadlineAware(Server,BtsOnServer,userr);
end
end
%-----------------------------------------------------------------RANDOM_HOP
function [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=RandomHop(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul)
load('CreatModel_Data.mat')
rng('shuffle')
SizeTask=model.SizeTasks;
BTS=max(Server);
WorkloasS=zeros(1,max(Server));
BtsOnServer=zeros(User,max(Server));
USER=zeros(User,max(Server));
userr=zeros(sum(RateTask),sum(RateTask));
for B = 1 : BTS
    t=ListBTSs(:,B);
    USER=find(t);
    for U=1:numel(USER)
        if (sum((B-Server)==0))
            BtsOnServer(USER(U),MyData.task(USER(U)))=B;
            userr(USER(U),MyData.task(USER(U)))=B;
            WorkloasS(1,B)=WorkloasS(1,B)+(SizeTask(USER(U)));
            ListServer(B,B)=B;
            select=B;
        else
            all=zeros(1,NumberOfServer);
            MinHop=zeros(1,NumberOfServer);
            for s=1:NumberOfServer
                store=0;
                [path,Hop]=shortestpath(G,B,Server(s));
                AllPath=path(1,:);
                MinHop(s)=Hop;
                SelectServer(s)=AllPath(end);
            end
            idxMin = find(MinHop==min(MinHop));
            all= SelectServer(idxMin);
            if length(all)==1
                select=all;
                BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                ListServer(B,select)=B;
            else
                select= randsample(all,1);
                BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                ListServer(B,select)=B;
                 SelectServer=select;
            end
        end
    end
   
end

if Schedul==1
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= FIFO(Server,BtsOnServer,userr);
else
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= DeadlineAware(Server,BtsOnServer,userr);
end
end
%-----------------------------------------------------------------GREEDY
function [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=Greedy(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul)

load('CreatModel_Data.mat')
rng('shuffle')
SizeTask=model.SizeTasks;
BTS=max(Server);
WorkloasS=zeros(1,BTS);
BtsOnServer=zeros(numel(Users),BTS);
USER=zeros(numel(Users),BTS);
userr=zeros(sum(RateTask),sum(RateTask));
for B = 1 : BTS
    t=ListBTSs(:,B);
    USER=find(t);
    for U=1:numel(USER)
        if (sum((B-Server)==0))
                BtsOnServer(USER(U),MyData.task(USER(U)))=B;
                userr(USER(U),MyData.task(USER(U)))=B;
            WorkloasS(1,B)=WorkloasS(1,B)+(SizeTask(USER(U)));
            ListServer(B,B)=B;
            select=B;
        else
            all=zeros(1,NumberOfServer);
            MinHop=zeros(1,NumberOfServer);
            for s=1:NumberOfServer
                store=0;
                [path,Hop]=shortestpath(G,B,Server(s));
                AllPath=path(1,:);
                MinHop(s)=Hop;
                SelectServer(s)=AllPath(end);
            end
            idxMin = find(MinHop==min(MinHop));
            all= SelectServer(idxMin);
            if length(all)==1
                select=all;
                    BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                    WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                    ListServer(B,select)=B;
            else
                cpusum=zeros(1,NumberOfServer);
                g=zeros(1,numel(all));
                for d=1:length(all)
                    g(d)=find(all(d)==Server);
                end
                cpusum=CpuServer(g);
                cpu= max(cpusum);
                [row,value] = find(cpu==CpuServer(g));
                disp(B);
                select=all(value(1));
                    BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                    WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                    ListServer(B,select)=B;
            end
        end
    end
end
if Schedul==1
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= FIFO(Server,BtsOnServer,userr);
else
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= DeadlineAware(Server,BtsOnServer,userr);
end
end
%-----------------------------------------------------------------ROUL_WHEEL
function [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=RouletteWheel(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul)

load('CreatModel_Data.mat')
rng('shuffle')
ProbUser=model.Probusers;
SizeTask=model.SizeTasks;
BTS=max(Server);
WorkloasS=zeros(1,BTS);
BtsOnServer=zeros(numel(Users),BTS);
USER=zeros(numel(Users),BTS);
userr=zeros(sum(RateTask),sum(RateTask));
% user=zeros(numel(RateTask),numel(RateTask));
for B = 1 : BTS
    t=ListBTSs(:,B);
    USER=find(t);
    %     user=zeros(numel(RateTask),numel(RateTask));
    for U=1:numel(USER)
        if (sum((B-Server)==0))
                BtsOnServer(USER(U),MyData.task(USER(U)))=B;
                userr(USER(U),MyData.task(USER(U)))=B;
            WorkloasS(1,B)=WorkloasS(1,B)+(SizeTask(USER(U)));
            ListServer(B,B)=B;
            select=B;
        else
            all=zeros(1,NumberOfServer);
            MinHop=zeros(1,NumberOfServer);
            for s=1:NumberOfServer
                store=0;
                [path,Hop]=shortestpath(G,B,Server(s));
                AllPath=path(1,:);
                MinHop(s)=Hop;
                SelectServer(s)=AllPath(end);
            end
            idxMin = find(MinHop==min(MinHop));
            all= SelectServer(idxMin);
            if length(all)==1
                select=all;
                    BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                    WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                    ListServer(B,select)=B;
            else
                ProbSerever=zeros(1,NumberOfServer);
                rangeProb=zeros(1,NumberOfServer);
                cpusum=0;
                for jj=1: length(all)
                    a=all(jj);
                    f=find(a==Server);
                    cpusum=cpusum+sum(CpuServer(f));
                end
                for jj=1: length(all)
                    a=all(jj);
                    f=find(a==Server);
                    ProbSerever(1,a)=(CpuServer(f)/cpusum)*100;
                    store=store+ ProbSerever(1,a);
                    rangeProb(1,a)=store;
                end
                for ff=1:length(all)
                    a=all(ff);
                        if (ProbUser(USER(U))<=rangeProb(1,a))
                            select=a;
                            BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                            WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                            ListServer(B,select)=B;
                            break;
                        end
                end
                
            end
        end
    end
end

if Schedul==1
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= FIFO(Server,BtsOnServer,userr);
else
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= DeadlineAware(Server,BtsOnServer,userr);
end
end
function [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=Balance(Server,WorklodOfBTS,WorkloadOfServer,BTS,ListBTSs,Schedul)
load('CreatModel_Data.mat')
rng('shuffle')
SizeTask=model.SizeTasks;
BTS=max(Server);
WorkloasS=zeros(1,BTS);
BtsOnServer=zeros(numel(Users),BTS);
USER=zeros(numel(Users),BTS);
userr=zeros(sum(RateTask),sum(RateTask));
for B = 1 : BTS
    t=ListBTSs(:,B);
    USER=find(t);
    for U=1:numel(USER)
        if (sum((B-Server)==0))
                BtsOnServer(USER(U),MyData.task(USER(U)))=B;
                userr(USER(U),MyData.task(USER(U)))=B;
            WorkloasS(1,B)=WorkloasS(1,B)+(SizeTask(USER(U)));
            ListServer(B,B)=B;
            select=B;
        else
            all=zeros(1,NumberOfServer);
            MinHop=zeros(1,NumberOfServer);
            for s=1:NumberOfServer
                store=0;
                [path,Hop]=shortestpath(G,B,Server(s));
                AllPath=path(1,:);
                MinHop(s)=Hop;
                SelectServer(s)=AllPath(end);
            end
            idxMin = find(MinHop==min(MinHop));
            all= SelectServer(idxMin);
            if length(all)==1
                select=all;

                    BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                    WorkloasS(1,select)=WorkloasS(1,select)+SizeTask(USER(U));
                    ListServer(B,select)=B;
            else
                g=0;
                  for d=1:length(all)
                    g(d)=find(all(d)==Server);
                  end
                  cpu=CpuServer(g);
                  for e=1:length(all)
                   cpuS(e)=WorkloasS(1,all(e))/cpu((e));
                  end
                    minWork=find(cpuS==min(cpuS));
                    select=(all(minWork(1)));
                    BtsOnServer(USER(U),MyData.task(USER(U)))=select;
                    WorkloasS(1,select)=WorkloasS(1,select)+SizeTasks(USER(U));
                    ListServer(B,select)=B;
                
            end
        end
    end
end
if Schedul==1
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= FIFO(Server,BtsOnServer,userr);
else
    [ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]= DeadlineAware(Server,BtsOnServer,userr);
end
end