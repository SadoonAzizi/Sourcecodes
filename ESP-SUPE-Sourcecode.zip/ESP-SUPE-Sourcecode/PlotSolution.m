function PlotSolution(Server,model,NumberOfServer)

plot(model.keeperX, model.keeperY, 'm*');
hold on;
h= plot(model.G,'b -o', 'MarkerSize', 30,'LineWidth', 2);
% set(gca, 'fontsize' , 15);
h.XData = [5 3 6 7 3.5 5 7 5 7   9 ];
h.YData = [8 6 6 7 3.5 4 5 2 2.5 3 ];

% plot(model.Arand,model.Brand,'r o', 'MarkerSize', 20,'markerfacecolor','r');
for i=1:NumberOfServer
     T(i)=model.XData(Server(i));   
     L(i)=model.YData(Server(i));
end
plot(T,L,'b o', 'MarkerSize', 30,'markerfacecolor','Y');

axis([0,12,0,10])
grid on;

end