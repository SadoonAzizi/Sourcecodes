
function [keep,j]=RouletWeel(P,p,l,k)
r=rand;
keep(k,l)=r;
Pp=sort(P,'ascend');
 C=cumsum(Pp);
if p==0
    jj=find(r<=C,1,'first');
    v=find(P==Pp(jj));
    j=v(1);
else
    j=p;
     jj=find(r<=C,1,'first');
     v=find(P==Pp(jj));
     j=v(1);
    while (j==p)
     rr=rand;
     keep(k,l)=rr;
     jj=find(rr<=C,1,'first');
     v=find(P==Pp(jj));
     j=v(1);
    end
   
end

end

