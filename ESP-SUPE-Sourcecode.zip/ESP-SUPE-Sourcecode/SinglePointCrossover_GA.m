function [y1, y2] = SinglePointCrossover_GA(x1, x2)
nVar= numel(x1);

c= randi([1 nVar-1]);

y1=[x1(1:c) x2(c+1:end)];
y2=[x2(1:c) x1(c+1:end)];

y1=Unique(y1,y2,1:c);
y2=Unique(y2,y1,1:c);
end

function x=Unique(x,xx,j)

n=union(x,xx);
xj=x(j);
x(j)=0;
a=ismember(x,xj);
x(a)=0;
x(j)=xj;
c=setdiff(n,x);
B=numel(x);
C=nnz(x);
D=B-C;
f=find(D);
if length(f)==1
x(x==0)=c(1);
else if length(D)>1
        for i=1:length(x)
            if x(i)==0
                len=length(c);
                for j=1:len
                    x(i)=c(j);
                end
            end 
        end
    end
end
end