%%
clc;
clear;
close all;
%  rng(1);
 
%% Problem Definition

nAnt= input('Enter number Of Ant: ');  
load('CreatModel_Data.mat')
top=0;
CostFunction= @(Server) MyCost(Users,NumberOfServer,Server,BTS,model,top,numBTS);
nVar= model.index1;
%% ACO Parametr
MaxIt=70;
% nAnt=1;
% Q=1;

% tau0=10*Q/(model.n*mean(model.SumWorkloadAllBTS(:))); %pheromone
alpha=1;
beta=1;
tau0=1;
rho=0.05;   %tabkhir
%% initialize
ll=sum(model.pheremon);
% DeltaTau=model.pheremon(nVar);  %mizan phermone har BTS
DeltaTau=model.pheremon(nVar)./ll;
DeltaTau=transpose(DeltaTau);
Tau=sum(DeltaTau);
tau=tau0*ones(1,model.n); % phermon avaliye har BTS
BestCost=zeros(MaxIt,1);
solu=zeros(MaxIt,NumberOfServer);
W=zeros(1,nAnt);
%Empty Ant
empty_ant.Server=[];
empty_ant.Cost=[];
empty_ant.WORKLOAD=[];
empty_ant.AverageComDelay=[];
empty_ant.WorkloadRate=[];
empty_ant.STD=[];
%Ant Colony Matrix
ant=repmat(empty_ant,nAnt,1);
%Best Ant
BestAnt.Cost=0;
SD_Result=inf;
for it=1:MaxIt
    for k=1:nAnt
        ant(k).Server=[];
        ant(k).AverageComDelay=[];
        ant(k).WORKLOAD=[];
        ant(k).Cost=[];
        ant(k).STD=[];
        format("shortG");
        x=sum(tau.^alpha.*DeltaTau.^beta);
        p=(tau.^alpha.*DeltaTau.^beta)./x;
      two=zeros(1,NumberOfServer);
      for l=1:NumberOfServer
%           disp(sum(p));
          r=rand;
          if l==1
              Pp=sort(p,'ascend');
              C=cumsum(Pp);
              jj=find(r<=C,1,'first');
              v=find(p==Pp(jj));
              j=v(1);
              two(1,l)=j;
          else
              Pp=sort(p,'ascend');
              C=cumsum(Pp);
              jj=find(r<=C,1,'first');
              v=find(p==Pp(jj));
              j=v(1);
           while (find(two==j))
            rr=rand;
            jj=find(rr<=C,1,'first');
            v=find(p==Pp(jj));
            j=v(1);
           end
            two(1,l)=j;
          end
          jj=model.index1(j);
          ant(k).Server=[ant(k).Server jj];
          V=find(model.index1==ant(k).Server(end));
          ant(k).Server(end)=P(jj);
      end
 
           [ant(k).AverageComDelay,ant(k).WORKLOAD,modell,ant(k).WorkloadRate]=CostFunction(ant(k).Server);
           [BestSol]=normalize(ant(k).AverageComDelay,ant(k).WORKLOAD);
           ant(k).Cost=BestSol;
            if BestSol>BestAnt.Cost
               BestAnt=ant(k);
           AvgWorkload=modell.avgWorkload;
%            for i=1:NumberOfServer
%                format("shortG");
%              C(i)=(ant(k).WORKLOAD(i)- AvgWorkload)^2; 
%            end
%            SDWorkload=sqrt(sum(C)/(NumberOfServer-1));
           SDWorkload=std(ant(k).WORKLOAD);
           AVGComDelay=ant(k).AverageComDelay;
           disp("SDWorkload "+SDWorkload);
           disp("AverageComDelay "+AVGComDelay);
           
               BestAnt.Cost=BestSol;   
               SelectServer=modell.Xij;
            end
    end

   %mohasebe sigma detatau      
  tau1=zeros(1,numel(model.index1));    
for k=1:nAnt
    Server=ant(k).Server;
        for l=1:NumberOfServer
            i=find(P==Server(l));
            D=find(model.index1==i);
            h=model.pheremon(i)/ll;
            tau1(D)=tau1(D)+h;
        end
end
d=sum(tau);
    tau=((1-rho)*tau)+tau1;
    BestCost(it)=BestAnt.Cost;
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]); 
    sol{it,1}=BestAnt.Server;
    solu(it,Server)=ant.Server;
%     figure(1);
%     PlotSolution_GA(BestAnt.Server,model,NumberOfServer);
end


disp("AvgWorkload "+AvgWorkload);
           disp("SDWorkload "+SDWorkload);
           disp("AverageComDelay "+AVGComDelay);
[STDworkload,sumWork,WorklodOfBTS,WorkloadOfServer,WorkLoadMIPS,modell]=Evaluation(BestAnt.Server,NumberOfServer,Users,BTS,model,numBTS);
Yij=modell.Xij;
ListBTSs=modell.ListBTS;
user=modell.user;
sumYij=sum(Yij,1);
    disp("Sum_Workload "+sumWork);
    disp("SD_Result "+STDworkload);
%     figure(1);
%     PlotSolution_GA(BestAnt.Server,model,NumberOfServer);
%     figure(2)
%     plot(BestCost);
%     xlabel('iteration');
%     ylabel('cost');
%     title('ACO Optimization')
%     text(25,BestAnt.Cost,['BestCost: ' num2str(STDworkload)],'Color',[1 0 1],'FontSize',14)
%     grid on;
   Enter = input('How many Algorithms do you Run?  '); 
   Enter=Enter*2;
   for i=1:Enter
        disp("Please select one of the algorithms");
        disp("1- Random ");
        disp("2- RandomHop ");
        disp("3- Greedy");
        disp("4- RouletteWheel ");
        disp("5- Balance ");
        Algorithm = input('Enter number: '); 
        Schedul = input('1: FIFO    OR   2:Deadline aware : '); 
        [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=LoadDistribution(BestAnt.Server,WorklodOfBTS,WorkloadOfServer,BTS,Algorithm,ListBTSs,Schedul);
        disp("AVG Respons "+AverageResponseTime);
    end


  
        
