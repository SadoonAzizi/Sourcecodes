function [pheremon]= phermon_BTS(load)
a=1;
phermon_load=(load); 
pheremon=((a*phermon_load));
end

