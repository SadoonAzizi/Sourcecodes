clc;
clear;
close all;

% rng(1);

load('CreatModel_Data.mat')

%% Problem Definition

CostFunction = @(Server) Fitness_GA(Users,NumberOfServer,Server,BTS,model,numBTS);
nVar=BTS;
VarSize=zeros(1,nVar);

%% GA Prameters
MaxIt=100;
nPop=20;
% sol=zeros(MaxIt);
solu=zeros(MaxIt,NumberOfServer);
pc=1;
nc=round(pc*nPop/2)*2;

pm=0.5;
nm=round(pm*nPop);


empty_individual.Server = [];
empty_individual.Cost = [];
empty_individual.Workload = [];
empty_individual.avgWorkload= [];
BestSol.Cost=0;

pop= repmat(empty_individual, nPop, 1);
for i=1 :nPop  
    %genarate random sol
    pop(i).Server=randsample(1:nVar,NumberOfServer); 
     pop(i).Server=P( pop(i).Server);
%----------------------   
%     for j=1:nVar
%         h=find(m==j);
%         if m(h)==j
%          pop(i).Server(j) =1; 
%         else
%          pop(i).Server(j) =0;  
%         end
%     end
%     m=find(pop(i).Server);
%----------------------
   [pop(i).Cost,pop(i).Workload,pop(i).avgWorkload] = CostFunction(pop(i).Server);
%     pop(i).Workload=pop(i).Workload(m);
end
    Costs=[pop.Cost];
    MaxSD=max(Costs);
    [Costs,SortOrder]=sort(Costs);
    pop=pop(SortOrder);
    for i=1:nPop
        pop(i).Cost=(MaxSD-pop(i).Cost)/MaxSD;
    end
     Costs=[pop.Cost];
         
    BestCost=zeros(MaxIt,1);
    BestServer=zeros(MaxIt,1);
    
for it=1:MaxIt
    
       P=Costs/sum(Costs);
       l=sum(P);
%     CrossOver
    popc= repmat(empty_individual, nc/2,2);

    for k=1:nc/2
        %Selection
            i1=Roulette_GA(P);
            i2=Roulette_GA(P);
        
        p1=pop(i1);
        p2=pop(i2);
        
        [popc(k,1).Server, popc(k,2).Server]=Crossover_GA(p1.Server,p2.Server);
        [popc(k,1).Cost,popc(k,1).Workload,popc(k,1).avgWorkload]=CostFunction(popc(k,1).Server);
        [popc(k,2).Cost,popc(k,2).Workload,popc(k,2).avgWorkload]=CostFunction(popc(k,2).Server);

    end
    popc=popc(:);
    
    popm=repmat(empty_individual,numel(popc),1);
    selectMut=rand(numel(popc),1);
    for k=1:numel(popc)
        if selectMut(k)<=pm
%       i=randi([1 nPop]);
        p=popc(k);
        
        popm(k).Server=Mutate_GA(p.Server);
        [popm(k).Cost,popm(k).Workload,popm(k).avgWorkload]=CostFunction(popm(k).Server);
        else
         popm(k)= popc(k);
         [popm(k).Cost,popm(k).Workload,popm(k).avgWorkload]=CostFunction(popm(k).Server);
        end
    end
     
     Costs=[popm.Cost];
     MaxSD=max(Costs);
    [Costs,SortOrder]=sort(Costs);
    popm=popm(SortOrder);
        for i=1:numel(pop)
         popm(i).Cost=(MaxSD-popm(i).Cost)/MaxSD;
        end 
        pop=[pop
         popm];
        Costs=[pop.Cost];
      [Costs,SortOrder]=sort(Costs,'descend');
       pop=pop(SortOrder);
       
       pop=pop(1:nPop);
       Costs=Costs(1:nPop);

% if  BestSol.Cost>pop(1).Cost
if BestSol.Cost<=pop(1).Cost
BestSol=pop(1); 
end
% end
avgWorkload=BestSol.avgWorkload;

BestCost(it)=BestSol.Cost;
%  disp([' avgWorkload= ' num2str(avgWorkload)]);
%  disp([' STDWorkload= ' num2str(BestSol.Cost)]);

 
 disp(['Itratoion: ' num2str(it) ', Best Cost= ' num2str(BestCost(it))]);
    sol{it,1}=BestSol.Server;
%     solu(it,Server)=ant.Server;
%     figure(1);
%     PlotSolution_GA(BestSol.Server,model,NumberOfServer);
    

end
% figure(2)
% plot(BestCost);
% xlabel('iteration');
% ylabel('cost');
% title('genetic Optimization')


           disp("AvgWorkload "+avgWorkload);
           disp("SDWorkload "+ std(BestSol.Workload));
[STDworkload,sumWork,WorklodOfBTS,WorkloadOfServer,WorkLoadMIPS,modell]=Evaluation(BestSol.Server,NumberOfServer,Users,BTS,model,numBTS);                                    
Yij=modell.Xij;
ListBTSs=modell.ListBTS;
user=modell.user;
sumYij=sum(Yij,1);
    disp("Sum_Workload "+sumWork);
    disp("SD_Result "+STDworkload);
%     figure(1);
%     PlotSolution_GA(BestSol.Server,model,NumberOfServer);
    Enter = input('How many Algorithms do you Run?  '); 
    Enter=Enter*2;
   for i=1:Enter
    disp("Please select one of the algorithms");
    disp("1- Random ");
    disp("2- RandomHop ");
    disp("3- Greedy");
    disp("4- RouletteWheel ");
    disp("5- Balance ");
    Algorithm = input('Enter number: '); 
    Schedul = input('1: FIFO    OR   2:Deadline aware : '); 
    [BtsOnServer,WorkloasS,ExeTime,ResponseTime,TTime,OrderOfExecution,AverageResponseTime]=LoadDistribution(BestSol.Server,WorklodOfBTS,WorkloadOfServer,BTS,Algorithm,ListBTSs,Schedul);
    disp("AVG Respons "+AverageResponseTime);
   end
   




