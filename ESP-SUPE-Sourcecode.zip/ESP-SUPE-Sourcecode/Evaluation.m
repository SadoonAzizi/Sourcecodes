
function [STDworkload,sumWork,WorklodOfBTS,WorkloadOfServer,WorkLoadMIPS,modell]=Evaluation(Server,NumberOfServer,Users,BTS,model,numBTS)
rng('shuffle')
BTS=max(Server);
workloadAllBTS=zeros(numel(Users),BTS);
% _________________________________________________________________________
Xij=zeros(numel(Users),BTS);
user=zeros(1,numel(Users));
% _________________________________________________________________________
SelectServer=zeros(1,NumberOfServer);
workload=zeros(1,BTS);
load=zeros(numel(Users),BTS);
%_________________________________________________________________________
SizeTask=model.SizeTasks;
RateTask=model.RateTask;
CpuBst=model.CpuServer;
SizeTasks=model.SizeTasks;
format("shortG");
ListBTS=zeros(numel(Users),BTS);
ListServer=zeros(numel(Users),NumberOfServer);
for k = 1 : numel(Users)
    % numel(Users) assign to BST
     b=numBTS(k);
    workloadAllBTS(k,b)=SizeTasks(k);
    ListBTS(k,b)=k;
    SumWorkloadAllBTS=sum(workloadAllBTS,1);
    % user check with all server BST
    if (sum((b-Server)==0))
        ListServer(k,b)=k;
        Xij(k,b)=1;
        user(1,k)=k;
        select=b;
        load(k,b)=SizeTasks(k);
        workload(b)=workload(b)+SizeTasks(k);
    else
        all=zeros(1,NumberOfServer);
        MinHop=zeros(1,NumberOfServer);
        for s=1:NumberOfServer
            store=0;
            [path,Hop]=shortestpath(model.G,b,Server(s));
            AllPath=path(1,:);
            MinHop(s)=Hop;
            SelectServer(s)=AllPath(end);
        end
        idxMin = find(MinHop==min(MinHop));
        all= SelectServer(idxMin);
        if length(all)==1
            select=all;
            load(k,select)=SizeTasks(k);
            workload(select)=workload(select)+SizeTasks(k);
        else
                select=randsample(all,1);
                load(k,select)=SizeTasks(k);
                workload(select)=workload(select)+SizeTasks(k);
        end
        SelectServer=select;
        ListServer(k,select)=k;
        Xij(k,SelectServer)=1;
    end
    
    ix = sum(abs(ListServer))~=0;
    N = ListServer(:, ix);
    servers=find(ix);
    
end

for i=1:length(servers)
    task=nonzeros(N(:,i));
end

%workload
workload=workload;
WorkloadOfServer=workload;
workLoads=zeros(1,numel(Server));
for i=1:numel(Server)
    workLoads(1,Server(i))=(workload(Server(i))/CpuBst(i));
    %                            ggg(1,Server(i))=(workload(Server(i))/numel(Server));
end
fff=find(workLoads);
for i=1:numel(fff)
    workLoadServer(i)=workLoads(fff(i));
end
WorkLoadMIPS=workLoads;
format("shortG");
sumWork=sum(SizeTasks);
avgWorkload=(sumWork/numel(Server));
format("shortG");
STDworkload=std(workLoadServer);
sumWork=sum(workload);

modell.Xij=Xij;
modell.user=user;
modell.avgWorkload=avgWorkload;
modell.CpuBst=CpuBst;
modell.ListServer=ListServer;
modell.ListBTS=ListBTS;
modell.SumWorkloadAllBTS=SumWorkloadAllBTS;
WorklodOfBTS=SumWorkloadAllBTS;

save('Evaluation.mat')


end