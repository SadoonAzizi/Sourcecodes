
function [workload,modelll]=MyCost_BTS(User,NumberOfServer,Server,BTS,model)
% rng(1);
workloadAllBTS=zeros(User,BTS);
load=zeros(User,BTS);
% _________________________________________________________________________
Xij=zeros(User,BTS);
user=zeros(User);
avg=zeros(1,BTS);
% _________________________________________________________________________
workload=zeros(1,BTS);
%_________________________________________________________________________
DisUserBst=model.DisUserBst;
SizeTask=model.SizeTask;
CpuServer=model.CpuServer;
ListServer=zeros(User,NumberOfServer);
for k = 1 : User
    % user assign to BST
    [minDis,b]=min(DisUserBst(k,:));
    workloadAllBTS(k,b)=sum(SizeTask(k,:));
    SumWorkloadAllBTS=sum(workloadAllBTS,1);
    % user check with all server BST
    if (sum((b-Server)==0))
        ListServer(k,b)=k;
        Xij(k,b)=1;
        select=b;
        workload(b)=workload(b)+sum(SizeTask(k,:));
        load(k,b)=sum(SizeTask(k,:));
        ListServer(k,select)=k;
    end
    
    ix = sum(abs(ListServer))~=0;
    N = ListServer(:, ix);
    servers=find(ix);
end
for i=1:length(servers)
    USER=nonzeros(N(:,i));
    for j=1:BTS
        if j==i
            avg(servers(i))=numel(USER);
            break;
        else
            avg(servers(i))=0;
        end
    end
end
%workload
workload=workload;
load=load;
Wsum=sum(workload);
format("shortG");
avgWorkload=(Wsum/sum(CpuServer));
format("shortG");
modelll.workload=workload;
modelll.avgWorkload=avgWorkload;
modelll.Wsum=Wsum;
modelll.SumWorkloadAllBTS=SumWorkloadAllBTS;
end