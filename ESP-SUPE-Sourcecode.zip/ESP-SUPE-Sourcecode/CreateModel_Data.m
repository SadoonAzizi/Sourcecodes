%%
clc;
clear;
close all;
% rng(1);
load('ReadDataset.mat')
Date= input('What day do you want? ');
FindDate=find(datee==Date);
h=0;
% for l=1:numel(FindDate)
for l=1:600
    if datee(l)==Date
        h=h+1;
        Day(h)=datee(l);
        Task(h)=user_id(l);
        X_BTS(h)=XX(l);
        Y_BTS(h)=YY(l);
    end
end
Day=transpose(Day);
Task=transpose(Task);
X_BTS=transpose(X_BTS);
Y_BTS=transpose(Y_BTS);
% X_BTS = cell2mat(X_BTS);
% Y_BTS = cell2mat(Y_BTS);

MyTablle = table(Day,X_BTS,Y_BTS);
[~,~,MyTablle.UserID_Idx] = unique(Task);
NumelUser=unique(MyTablle.UserID_Idx);
for i=1:length(ll)
    [bts,bt]=find(xn==i);
    if (length(bt))==0
    xBTS=find(X_BTS==ll(i,1));
    yBTS=find(Y_BTS==ll(i,2));
    xBTS=unique(xBTS);
    yBTS=unique(yBTS);
    w=numel(xBTS)+numel(yBTS);
    uu=w./2;
    for j=1:uu
        if (xBTS(j)==yBTS(j))
           Day(xBTS(j))=0;
           MyTablle.UserID_Idx(xBTS(j))=0;
           X_BTS(xBTS(j))=0;
           Y_BTS(xBTS(j))=0;
        end
    end
    end
end
D=find(Day==0);
Day(D)=[];

D=find(X_BTS==0);
X_BTS(D)=[];

D=find(Y_BTS==0);
Y_BTS(D)=[];
MyTable = table(Day,X_BTS,Y_BTS);
D=find(MyTablle.UserID_Idx);
UserID=MyTablle.UserID_Idx(D);
[MyTable.UserID_Idx]=UserID;

NumberOfServer = input('Enter number Of Server: ');
model.NumberOfServer=NumberOfServer;
CpuBst=zeros(1,NumberOfServer);
CpuServer=zeros(1,NumberOfServer);
for h=1:NumberOfServer
    CpuServer(h) =randi([8000 16000]);
end
sumCpu=sum(CpuServer);
AvgCpuServer=sumCpu/NumberOfServer;
for t=1:numel(UserID)
    if t==1
        Use(t)=MyTable.UserID_Idx(t);
        user{t}=find(MyTable.UserID_Idx==Use(t));
         d=find(MyTable.UserID_Idx==Use(t));
        if numel(d)>1
            p=0;
            v=0;
            for f=2:numel(d)
                MyTable.UserID_Idx(d(f))=0;
                p(f)=MyTable.X_BTS(d(f));
                v(f)=MyTable.Y_BTS(d(f));
            end
        end
        Rtask(t,1)=numelCell(user(t));
        Rtask=transpose(Rtask);
        for u=1:Rtask(t,1)
            Days(u,1)=MyTable.Day(t);
            Users(u,1)=Use(t);
            task(u,1)=u;
            X(u,1)=MyTable.X_BTS(t);
            Y(u,1)=MyTable.Y_BTS(t);
            SizeTasks(u,1) = randi([500 5000]);
            InFs(u,1) = randi([500 5000]);
            OutFs(u,1) = randi([100 1000]);
            Generates(u,1)=randi([1 60000]);
            Deadlines(u,1)= (SizeTasks(u,1)/AvgCpuServer)* randi([1 10])*1000;
            UpDeads(u,1)=Deadlines(u,1)+ Generates(u,1);
            Probusers(u,1)=randi([1 100]);
        end
    else
        Use(t)=MyTable.UserID_Idx(t);
        if Use(t)~=0
        user{t}=find(MyTable.UserID_Idx==Use(t));
        d=find(MyTable.UserID_Idx==Use(t));
        if numel(d)>1
            p=0;
            v=0;
            for f=2:numel(d)
                MyTable.UserID_Idx(d(f))=0;
                p(f)=MyTable.X_BTS(d(f));
                v(f)=MyTable.Y_BTS(d(f));
            end
        end
        Rtask(t,1)=numelCell(user(t));
        y=Rtask(t,1)-1;
        i=0;
        if numel(d)==1
            w=numel(task)+1;
            z=numel(task)+Rtask(t,1);
        else
            w=numel(task)+1;
            z=numel(task)+Rtask(t,1);
        end
        cunter=0;
        for u=w:z
            Days(u,1)=MyTable.Day(t);
            Users(u,1)=Use(t);
            i=i+1;
            cunter=cunter+1;
            task(u,1)=i;
            if cunter>1
                  p=nonzeros(p);
                  v=nonzeros(v);
                  X(u,1)=p(cunter-1);
                  Y(u,1)=v(cunter-1);
            else
                X(u,1)=MyTable.X_BTS(t);
                Y(u,1)=MyTable.Y_BTS(t);
            end
            Days(u,1)=MyTable.Day(t);    
            SizeTasks(u,1) = randi([500 5000]);
            InFs(u,1) = randi([500 5000]);
            OutFs(u,1) = randi([100 1000]);
            Generates(u,1)=randi([1 60000]);
            Deadlines(u,1)= (SizeTasks(u,1)/AvgCpuServer)* randi([1 10])*1000;
            UpDeads(u,1)=Deadlines(u,1)+ Generates(u,1);
            Probusers(u,1)=randi([1 100]);
        end        
        end
    end
    
end
location=[X_BTS,Y_BTS];
l=unique(location,'rows');

for r=1:numel(X)
    XY=[X(r),Y(r)];
    XData(r)=X(r);
    YData(r)=Y(r);
    [u,k]=find(ismember(ll,XY,'rows'));
    numBTS(r)=unique(u);
end
P=(unique(numBTS));

BTS=numel(unique(numBTS));
workload=zeros(length(Days),1);
numBTS=transpose(numBTS);
MyData = table(Days,Users,task,X,Y,numBTS,SizeTasks,InFs,OutFs,Generates,Deadlines);
for g=1:length(MyData.Days)
    [r,c]=find(MyData.numBTS(g)==MyData.numBTS);
    workload(r,1)=sum(MyData.SizeTasks(r));
end
[MyData.Workload]=workload;
writetable(MyData,'myData500.xlsx');
model.MyData=MyData;
for i=1:numel(P)
    [g,d]=find(numBTS==P(i));
    w=(g(1));
    WorkLOad(i,1)=workload(w,1);
end
for d=1:length(MyData.Days)
    [R,T]=find(Users==Users(d));
    RateTask(Users(d))=numel(R);
%     if RateTask(Users(d))==0
%         RateTask(Users(d))=[];
%     end
end
RateTask=transpose(RateTask);
NumUser=numel(unique(Users));
User=NumUser;
SizeTask=zeros(User,max(RateTask));
InF=zeros(User,max(RateTask));
OutF=zeros(User,max(RateTask));
Deadline=zeros(User,max(RateTask));
upDead=zeros(User,max(RateTask));
Generate=zeros(User,max(RateTask));
ProbUser=zeros(User,max(RateTask));

for i =1:User
    k=0;
    for j=1:RateTask(i,1)
        kk=find(MyData.Users==i);
        k=k+1;
        SizeTask(i,j) =MyData.SizeTasks(kk(k));
        InF(i,j) = MyData.InFs(kk(k)) ;
        OutF(i,j) = MyData.OutFs(kk(k));
        Generate(i,j)= MyData.Generates(kk(k));
        Deadline(i,j)= MyData.Deadlines(kk(k));
        upDead(i,j)= UpDeads(kk(k));
        ProbUser(i,j)= Probusers(kk(k));
    end
end


% lat = X;
% lon = Y;
% geoscatter(lat,lon,'^')
% _________________________________________________________________________

c=randperm(BTS);
index1= randsample(c,BTS);
index1=sort(index1);
Arand = XData(index1);
Brand = YData(index1);
randd=randi([1 10]);


model.randd=randd;
model.Bandwith=Bandwith;
model.G=G;
model.CpuServer=CpuServer;
model.RateTask=RateTask;

model.SizeTask=SizeTask;
model.InF=InF;
model.OutF=OutF;
model.Generate=Generate;
model.ProbUser=ProbUser;
model.upDead=upDead;
model.Deadline=Deadline;
model.CpuBst=CpuBst;

model.SizeTasks=SizeTasks;
model.InFs=InFs;
model.OutFs=OutFs;
model.Generates=Generates;
model.Probusers=Probusers;
model.UpDeads=UpDeads;
model.Deadlines=Deadlines;

SumWorkloadAllBTS=WorkLOad;
AVGworlload=(sum(WorkLOad)/sum(CpuServer));
[pheremon]=phermon_BTS(WorkLOad); 
n=numel(index1);
model.workload=WorkLOad;
model.SumWorkloadAllBTS=SumWorkloadAllBTS;
model.pheremon=pheremon;
model.index1=index1;
model.Arand=Arand;
model.Brand=Brand;
model.n=n;
model.A=A;
model.xn=xn;
model.yn=yn;
model.XData=XData;
model.YData=YData;
model.Bandwith=Bandwith;
model.SizeTask=SizeTask;
model.G=G;
save('CreatModel_Data.mat')