function [ObjectivFunction]= normalize(AverageComDelay,Workload)
a=0.5;

STDload=std(Workload);
phermon_load=1/(STDload);

phermon_ComDelay=1/sqrt(AverageComDelay); 
ObjectivFunction=((a*(phermon_load))+(1-a)*(phermon_ComDelay));

end

