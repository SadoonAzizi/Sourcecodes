function [idx,X,C]=cluster(NumberOfServer)
load('CreatModel_Data.mat')

X = l;
[idx,C] = kmedoids(X,NumberOfServer);
% for s=1:NumberOfServer
%     server=find(C(s,:)==X(:,:));
% end

 for j=1:NumberOfServer
  clluster{:,1}=find(idx==j);   
  k=(X(clluster{:,:},:));
 end
 
%     plot(C(:,1),C(:,2),'Y o', 'MarkerSize', 30,'markerfacecolor','Y');
%     for s=1:NumberOfServer
%       text(C(s,1)-0.2,C(s,2),['S' num2str(s)],'Color',[0 0 0],'FontSize',14)
%     end
end
%  gscatter(h.XData,h.YData,idx,'mgc','o',30)


% legend('Cluster 1','Cluster 2','Cluster 3','Cluster Centroid')

