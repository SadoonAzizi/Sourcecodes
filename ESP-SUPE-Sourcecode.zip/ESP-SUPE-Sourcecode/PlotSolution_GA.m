function PlotSolution_GA(Server,model,NumberOfServer)
plot(model.keeperX, model.keeperY, 'm*');
% for i=1:numel(model.keeperX)
% text(model.keeperX(i),model.keeperY(i)+0.2,['t' num2str(i)],'Color',[0 0 0],'FontSize',9)
% end
hold on;
h= plot(model.G,'b -o', 'MarkerSize', 30,'LineWidth', 2);
plot(model.Arand,model.Brand,'b o', 'MarkerSize', 20,'markerfacecolor','b');
text(5,8,'1','Color',[1 1 1],'FontSize',14)
text(3,6,'2','Color',[1 1 1],'FontSize',14)
text(6,6,'3','Color',[1 1 1],'FontSize',14)
text(7,7,'4','Color',[1 1 1],'FontSize',14)
text(3.5,3.5,'5','Color',[1 1 1],'FontSize',14)
text(5,4,'6','Color',[1 1 1],'FontSize',14)
text(7,5,'7','Color',[1 1 1],'FontSize',14)
text(5,2,'8','Color',[1 1 1],'FontSize',14)
text(7,2.5,'9','Color',[1 1 1],'FontSize',14)
text(9,3,'10','Color',[1 1 1],'FontSize',14)
% XData = [5 3 6 7 3.5 5 7 5 7   9 ];
% YData = [8 6 6 7 3.5 4 5 2 2.5 3 ];


% set(gca, 'fontsize' , 15);
h.XData = [5 3 6 7 3.5 5 7 5 7   9 ];
h.YData = [8 6 6 7 3.5 4 5 2 2.5 3 ];


for i=1:NumberOfServer
     T(i)=model.XData(Server(i));   
     L(i)=model.YData(Server(i));
end
plot(T,L,'b o', 'MarkerSize', 30,'markerfacecolor','Y');
for s=1:NumberOfServer
text(T(s)-0.2,L(s),['S' num2str(s)],'Color',[0 0 0],'FontSize',14)
end
axis([0,12,0,10])
grid on;

end