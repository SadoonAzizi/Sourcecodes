function [d1km] = getDistance(X_BTS,Y_BTS)

for i=1:numel(X_BTS)
    la(i)=X_BTS(i);
    lo(i)=Y_BTS(i);
    for j=1:numel(X_BTS)
        lat(j)=X_BTS(j);
        lon(j)=Y_BTS(j);
        radius=6371;
        lat1=la(i)*pi/180;
        lat2=lat(j)*pi/180;
        lon1=lo(i)*pi/180;
        lon2=lon(j)*pi/180;
        deltaLat=lat2-lat1;
        deltaLon=lon2-lon1;
        a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
        c=2*atan2(sqrt(a),sqrt(1-a));
        d1km(i,j)=radius*c;    %Haversine distance
        x=deltaLon*cos((lat1+lat2)/2);
        y=deltaLat;
        d2km(i,j)=radius*sqrt(x*x + y*y); %Pythagoran distance
    end
end

end

