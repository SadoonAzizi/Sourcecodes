function [y1, y2] = Crossover_GA(x1,x2)

%  pSinglePoint=0.1;
%  pDoublePoint=0.2;
%  pUniform=1-pSinglePoint-pDoublePoint;
%  METHOD=Roulette([pSinglePoint pDoublePoint pUniform]);
 
%  switch METHOD
%       case 1
           [y1, y2]=SinglePointCrossover_GA(x1,x2);
%       case 2
%            [y1, y2]=DoublePointCrossover(x1,x2);
%       otherwise     
%            [y1, y2]=UniformCrossover(x1,x2);
  end

