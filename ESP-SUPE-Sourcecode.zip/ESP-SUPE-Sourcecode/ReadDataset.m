%%
clc;
clear;
close all;
% rng(1);
[num,txt,raw] = xlsread('data_6.1~6.1.xlsx') ;
for i=1:length(raw)
    date(i)=((raw(i,2)));
    user_id(i)=((raw(i,7)));
    latitude(i)=((num(i,5)));
    longitude(i)=((num(i,6)));
end
[num2,txt2,raw2] = xlsread('data_6.16~6.30.xlsx') ;
j=1;
for i=length(raw)+1:length(raw)+length(raw2)
    date(i)=((raw2(j,2)));
    user_id(i)=((raw2(j,7)));
    latitude(i)=((num2(j,5)));
    longitude(i)=((num2(j,6)));
    j=j+1;
end
[num3,txt3,raw3] = xlsread('data_7.1~7.15.xlsx') ;
k=1;
for i=length(raw)+length(raw2)+1:length(raw)+length(raw2)+length(raw3)
    date(i)=((raw3(k,2)));
    user_id(i)=((raw3(k,7)));
    latitude(i)=((num3(k,5)));
    longitude(i)=((num3(k,6)));
    k=k+1;
end
% 
% [num4,txt4,raw4] = xlsread('data_7.16~7.31.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)
%     date(i)=((raw4(k,2)));
%     user_id(i)=((raw4(k,7)));
%     latitude(i)=((raw4(k,5)));
%     longitude(i)=((raw4(k,6)));
%     k=k+1;
% end
% [num5,txt5,raw5] = xlsread('data_8.1~8.15.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)
%     date(i)=((raw5(k,2)));
%     user_id(i)=((raw5(k,7)));
%     latitude(i)=((raw5(k,5)));
%     longitude(i)=((raw5(k,6)));
%     k=k+1;
% end
% [num6,txt6,raw6] = xlsread('data_8.16~8.31.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)
%     date(i)=((raw6(k,2)));
%     user_id(i)=((raw6(k,7)));
%     latitude(i)=((raw6(k,5)));
%     longitude(i)=((raw6(k,6)));
%     k=k+1;
% end
% 
% [num7,txt7,raw7] = xlsread('data_9.1~9.15.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)
%     date(i)=((raw7(k,2)));
%     user_id(i)=((raw7(k,7)));
%     latitude(i)=((raw7(k,5)));
%     longitude(i)=((raw7(k,6)));
%     k=k+1;
% end
% [num8,txt8,raw8] = xlsread('data_9.16~9.30.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)
%     date(i)=((raw8(k,2)));
%     user_id(i)=((raw8(k,7)));
%     latitude(i)=((raw8(k,5)));
%     longitude(i)=((raw8(k,6)));
%     k=k+1;
% end
% % 
% [num9,txt9,raw9] = xlsread('data_10.1~10.15.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)
%     date(i)=((raw9(k,2)));
%     user_id(i)=((raw9(k,7)));
%     latitude(i)=((raw9(k,5)));
%     longitude(i)=((raw9(k,6)));
%     k=k+1;
% end
% [num10,txt10,raw10] = xlsread('data_10.16~10.31.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)+length(raw10)
%     date(i)=((raw10(k,2)));
%     user_id(i)=((raw10(k,7)));
%     latitude(i)=((raw10(k,5)));
%     longitude(i)=((raw10(k,6)));
%     k=k+1;
% end
% % 
% [num11,txt11,raw11] = xlsread('data_11.1~11.15.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)+length(raw10)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)+length(raw10)+length(raw11)
%     date(i)=((raw11(k,2)));
%     user_id(i)=((raw11(k,7)));
%     latitude(i)=((raw11(k,5)));
%     longitude(i)=((raw11(k,6)));
%     k=k+1;
% end
% [num12,txt12,raw12] = xlsread('data_11.16~11.30.xlsx') ;
% k=1;
% for i=length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)+length(raw10)+length(raw11)+1:length(raw)+length(raw2)+length(raw3)+length(raw4)+length(raw5)+length(raw6)+length(raw7)+length(raw8)+length(raw9)+length(raw10)+length(raw11)+length(raw12)
%     date(i)=((raw12(k,2)));
%     user_id(i)=((raw12(k,7)));
%     latitude(i)=((raw12(k,5)));
%     longitude(i)=((raw12(k,6)));
%     k=k+1;
% end

datee = cell2mat(date);
datee = transpose(datee);
% XX = cell2mat(latitude);
XX = transpose(latitude);
% YY = cell2mat(longitude);
YY = transpose(longitude);

locate=[XX,YY];
ll=unique(locate,'rows');

[km]=getDistance(ll(:,1),ll(:,2));
A=zeros(length(ll),length(ll));
for x=1:length(ll)
    for y=1:length(ll)
        if km(x,y)==0
            A(x,y)=0;
        elseif (km(x,y)<=10)
            A(x,y)=1;
        else
            A(x,y)=0;
        end
    end
end
B = 1000;
Bandwith = A.*B ;

[n,m]=find(A(:,:)==1);
xn=m;
yn=n;

xn = transpose(xn);
yn = transpose(yn);
G = graph(xn,yn);

% 
% lat = XX;
% lon = YY;
% geoscatter(lat,lon,'^')
save('ReadDataset.mat')