%%
clc;
clear;
close all;
% rng(1);
numberOfBTS=20;
numberOfUsers = input('Enter number Of Users: ');
numberOfServer = input('Enter number Of Server: ');  
 
% _______________________0_____matrix % User Propertice____________________

input=randi([1 10]);
SizeTask=zeros(numberOfUsers,1);
InF=zeros(numberOfUsers,1);
OutF=zeros(numberOfUsers,1);
MemTask=zeros(numberOfUsers,1);
Deadline=zeros(numberOfUsers,1);
Generate=zeros(numberOfUsers,1);
upDead=zeros(numberOfUsers,1);
ProbUser=zeros(numberOfUsers,1);
% _________________________________________________________________________


% _________________________________________________________________________
MemServer=zeros(1,numberOfServer);
CpuBst=zeros(1,numberOfServer);
% _________________________________________________________________________

SelectServer=zeros(1,numberOfServer);
% _________________________________________________________________________
A=[ 0 1 0 0 0 0 0 0 0 0  0  0  0  1  0  0  0  0  0  0 ;
   1 0 1 0 1 1 0 0 0 0  0  0  1  0  0  0  0  0  0  0 ;
   0 1 0 1 1 1 1 0 0 0  0  1  0  0  0  1  0  0  0  0 ;
   0 0 1 0 0 0 1 1 0 0  1  0  0  0  0  0  0  0  1  0 ;
   0 1 1 0 0 1 0 0 1 1  0  0  0  0  0  0  0  0  0  0 ;
   0 1 1 0 1 0 1 0 1 0  0  0  0  0  0  0  0  0  0  0 ;
   0 0 1 1 0 1 0 1 0 1  0  0  0  0  0  0  1  0  0  0 ;
   0 0 0 1 0 0 1 0 1 0  0  1  0  0  0  0  0  0  0  0 ;
   0 0 0 0 1 1 0 1 0 0  0  0  1  0  0  1  0  0  0  0 ;
   0 0 0 0 1 0 1 0 0 0  1  0  1  0  1  0  0  0  0  0 ;
   0 0 0 1 0 0 0 0 0 1  0  1  0  0  1  0  0  1  0  0 ;
   0 0 1 0 0 0 0 1 0 0  1  0  0  0  0  1  0  0  0  0 ;
   0 1 0 0 0 0 0 0 1 1  0  0  0  0  0  0  1  0  0  0 ;
   1 0 0 0 0 0 0 0 0 0  0  0  0  0  1  0  0  1  0  0 ; 
   0 0 0 0 0 0 0 0 0 1  1  0  0  1  0  0  0  0  1  0 ;
   0 0 1 0 0 0 0 0 1 0  0  1  0  0  0  0  0  0  0  1 ;
   0 0 0 0 0 0 1 0 0 0  0  0  1  0  0  0  0  0  0  0 ;
   0 0 0 0 0 0 0 0 0 0  1  0  0  1  0  0  0  0  1  0 ;
   0 0 0 1 0 0 0 0 0 0  0  0  0  0  1  0  0  1  0  1 ;
   0 0 0 0 0 0 0 0 0 0  0  0  0  0  0  1  0  0  1  0 ;];

% minAllowableDistance = 5;
% minAllow=0.01;

B = 1000;
P = 0.002 + (0.005-0.002) * rand(numberOfBTS,numberOfBTS);
Bandwith = A.*B ;
Prop=A.*P;

% ---------------------------Relation Edges between BTSes------------------
xn = [1 1 2 2 2 2 3 3 3 3 3 3 4 4 4 4 5 5 5 6 6 7 7 7 8 8 9 9 10 10 10 11 11 11 12 13 14 14 15 16 18 19 ];
yn = [2 14 3 6 13 5 5 4 12 16 7 6 7 8 11 19 6 9 10 7 9 8 10 17 12 9 16 13 15 13 11 12 15 18 16 17 15 18 19 20 19 20 ];
G = graph(xn,yn);
% ----------------------------------number Of Users------------------------
x = 12-12*rand(1,1000) ;
y = 12-12*rand(1,1000) ;

% ----------------------------------------------------------
XData = [2 2 2 2 4 4 4 4 6 6 6 6 8 8 8 8 10 10 10 10 ];
YData = [2 4 6 8 2 4 6 8 2 4 6 8 2 4 6 8 2 4 6 8 ];

c=randperm(20);
index1= randsample(c, numberOfServer);
   
Arand = XData(index1);
Brand = YData(index1);

    for f=1:numberOfServer
        MemServer(index1(f)) = randi([50000 100000]);
        CpuBst(index1(f)) =randi([8000 16000]);
    end
%               fg=sum(CpuBst)
                sumCpu=sum(CpuBst);
                AvgCpuServer=sumCpu/numberOfServer;
    for i = 1 :numberOfUsers

            SizeTask(i,1) = randi([500 5000]);
            InF(i,1) = randi([500 5000]);
            OutF(i,1) = randi([100 1000]);
            MemTask(i,1)= randi([32 64]);
            Deadline(i,1)= (SizeTask(i,1)/AvgCpuServer)* randi([1 10])*1000;
%           Generate(i,1)=0;
            Generate(i,1)=randi([1 1000]);
            upDead(i,1)=Deadline(i,1)+ Generate(i,1); 
            ProbUser(i,1)=randi([1 100]); 
    end
save('pqfile.mat','numberOfUsers','numberOfServer','SizeTask','InF','OutF','MemTask','Deadline','Generate','upDead','ProbUser','MemServer','CpuBst','A','B','P','x','y','c','index1','Arand','Brand','','','','','')

